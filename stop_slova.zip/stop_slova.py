import csv

file1= "query.tsv" #Файл, который нужно почистить
file2= "stop.txt" #Файл с лишними словами
file_res= "result.tsv" #Результат - "чистый" файл
file_res_stop= "stop_zaprosi.tsv" #Файл с "грязными" зпросами

stop_slova = set()

with open(file2, encoding="UTF-8") as read:
    for line in read:
        stop_slova.add(tuple(line.lower().replace("\n","").split()))


with open(file1, encoding="UTF-8", newline="") as read:
    reader = csv.DictReader(read, delimiter="\t") #Принимает .tsv файлы с разделителем "Знак табуляции"
    headers = reader.fieldnames

    with open(file_res, "w", encoding="UTF-8", newline="") as write:
        writer = csv.DictWriter(write, delimiter="\t", fieldnames=headers)
        for line in reader:
            if not any(map(lambda x: all(map(lambda y: y in tuple(line["Запрос"].lower().split()),x)),stop_slova)):
                writer.writerow(line) #В начальном файле query.tsv хедер, по которому будем чистить стоп слова заменяем на "Запрос"

with open(file1, encoding="UTF-8", newline="") as read:
    reader = csv.DictReader(read, delimiter="\t")
    headers = reader.fieldnames
                
    with open(file_res_stop, "w", encoding="UTF-8", newline="") as write:
        writer = csv.DictWriter(write, delimiter="\t", fieldnames=headers)
        for line in reader:
            if any(map(lambda x: all(map(lambda y: y in tuple(line["Запрос"].lower().split()),x)),stop_slova)):
                writer.writerow(line)