import csv, os

directory = "papka" # название папки, в которой мы хотим сцепить файлы в один.
res = "result.tsv" # результирующий tsv-файл.
files_csv = []
walker = os.walk(directory)
for r, d, f in walker:
    print(f)
    for file in f:
        if ".tsv" in file:
            files_csv.append(r+"/"+file) # можем работать как с tsv-файлами,
        if ".csv" in file:
            files_csv.append(r+"/"+file) # так и с csv-файлами сразу.

with open(res, "w", encoding="UTF-8", newline="") as write:
    writer = csv.writer(write, delimiter="\t")
    writer.writerow(["URL", "Keys", "Numbers"]) # здесь мы можем добавлять и изменять хедеры
    for file in files_csv:
        with open(file, encoding="UTF-8") as read:
            temp = next(read)
            if ";" in temp:
                delim = ";" # также подходят
            elif "\t" in temp:
                delim="\t" # любые!
            else:
                delim="," # разделители.
            reader = csv.reader(read, delimiter=delim)
            for line in reader:
                if line[0]:
                    writer.writerow(line)
                    writer.writerows(row for row in reader)
                else:
                    print(line)

